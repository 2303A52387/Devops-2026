const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.userId) return next();
  req.flash('error', 'Please log in to access this page.');
  res.redirect('/auth/login');
};

const isAdmin = (req, res, next) => {
  if (req.session && req.session.role === 'admin') return next();
  req.flash('error', 'Admin access required.');
  res.redirect('/dashboard');
};

const isGuest = (req, res, next) => {
  if (!req.session || !req.session.userId) return next();
  res.redirect('/dashboard');
};

module.exports = { isAuthenticated, isAdmin, isGuest };
