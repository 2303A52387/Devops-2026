const mongoose = require('mongoose');

const PaperSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  author: { type: String, required: true, trim: true },
  category: {
    type: String,
    required: true,
    enum: ['Machine Learning', 'Deep Learning', 'Computer Vision', 'NLP', 'Bioinformatics', 'Data Science', 'Cybersecurity', 'IoT', 'Cloud Computing', 'Other']
  },
  abstract: { type: String, required: true },
  year: { type: Number, required: true },
  pdfFile: { type: String, required: true },
  fileSize: { type: Number, default: 0 },
  uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

PaperSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Paper', PaperSchema);
