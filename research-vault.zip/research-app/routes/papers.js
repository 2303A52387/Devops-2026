const express = require('express');
const router = express.Router();
const papers = require('../controllers/papersController');
const { isAuthenticated } = require('../middleware/auth');
const { uploadPDF } = require('../middleware/multer');

router.get('/', isAuthenticated, papers.index);
router.get('/create', isAuthenticated, papers.create);
router.post('/', isAuthenticated, uploadPDF.single('pdfFile'), papers.store);
router.get('/:id', isAuthenticated, papers.show);
router.get('/:id/edit', isAuthenticated, papers.edit);
router.put('/:id', isAuthenticated, papers.update);
router.delete('/:id', isAuthenticated, papers.destroy);

module.exports = router;
