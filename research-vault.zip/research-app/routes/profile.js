const express = require('express');
const router = express.Router();
const profile = require('../controllers/profileController');
const { isAuthenticated } = require('../middleware/auth');
const { uploadAvatar } = require('../middleware/multer');

router.get('/', isAuthenticated, profile.index);
router.put('/', isAuthenticated, uploadAvatar.single('avatar'), profile.update);
router.put('/password', isAuthenticated, profile.changePassword);

module.exports = router;
