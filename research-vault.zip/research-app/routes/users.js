const express = require('express');
const router = express.Router();
const users = require('../controllers/usersController');
const { isAuthenticated, isAdmin } = require('../middleware/auth');

router.get('/', isAuthenticated, isAdmin, users.index);
router.get('/:id/edit', isAuthenticated, isAdmin, users.edit);
router.put('/:id', isAuthenticated, isAdmin, users.update);
router.delete('/:id', isAuthenticated, isAdmin, users.destroy);

module.exports = router;
