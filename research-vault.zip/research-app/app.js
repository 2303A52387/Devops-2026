require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const methodOverride = require('method-override');
const flash = require('express-flash');
const path = require('path');
const connectDB = require('./config/db');

const app = express();

// Connect DB
connectDB();

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Body parsers
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Method override (for PUT/DELETE in forms)
app.use(methodOverride('_method'));

// Session
app.use(session({
  secret: process.env.SESSION_SECRET || 'researchvault_secret_key',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  cookie: {
    maxAge: 1000 * 60 * 60 * 24, // 1 day
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production'
  }
}));

// Flash messages
app.use(flash());

// Global locals for templates
app.use((req, res, next) => {
  res.locals.session = req.session;
  res.locals.messages = {
    success: req.flash('success'),
    error: req.flash('error')
  };
  next();
});

// Routes
app.use('/auth', require('./routes/auth'));
app.use('/papers', require('./routes/papers'));
app.use('/users', require('./routes/users'));
app.use('/profile', require('./routes/profile'));

// Dashboard
const { isAuthenticated } = require('./middleware/auth');
const { getDashboard } = require('./controllers/dashboardController');
app.get('/dashboard', isAuthenticated, getDashboard);

// Root redirect
app.get('/', (req, res) => {
  if (req.session && req.session.userId) return res.redirect('/dashboard');
  res.redirect('/auth/login');
});

// 404 handler
app.use((req, res) => {
  res.status(404).send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>404 — ResearchVault</title>
      <style>
        body { background:#0f0f1a; color:#e2e8f0; font-family:sans-serif; display:flex; align-items:center; justify-content:center; min-height:100vh; text-align:center; }
        h1 { font-size:80px; margin:0; color:#6366f1; }
        p { color:#94a3b8; }
        a { color:#6366f1; }
      </style>
    </head>
    <body>
      <div>
        <h1>404</h1>
        <p>Page not found.</p>
        <a href="/">← Go home</a>
      </div>
    </body>
    </html>
  `);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 ResearchVault running on http://localhost:${PORT}`));
