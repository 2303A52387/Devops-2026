const User = require('../models/User');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

exports.index = async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);
    res.render('profile/index', { title: 'My Profile', profileUser: user });
  } catch (err) {
    req.flash('error', 'Failed to load profile.');
    res.redirect('/dashboard');
  }
};

exports.update = async (req, res) => {
  try {
    const { name, email } = req.body;
    if (!name || !email) {
      req.flash('error', 'Name and email are required.');
      return res.redirect('/profile');
    }
    const existing = await User.findOne({ email, _id: { $ne: req.session.userId } });
    if (existing) {
      req.flash('error', 'Email already in use.');
      return res.redirect('/profile');
    }
    const updateData = { name, email };
    if (req.file) updateData.avatar = req.file.filename;
    await User.findByIdAndUpdate(req.session.userId, updateData);
    req.session.userName = name;
    req.flash('success', 'Profile updated successfully!');
    res.redirect('/profile');
  } catch (err) {
    req.flash('error', 'Update failed.');
    res.redirect('/profile');
  }
};

exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;
    if (!currentPassword || !newPassword || !confirmPassword) {
      req.flash('error', 'All password fields are required.');
      return res.redirect('/profile');
    }
    if (newPassword !== confirmPassword) {
      req.flash('error', 'New passwords do not match.');
      return res.redirect('/profile');
    }
    if (newPassword.length < 6) {
      req.flash('error', 'New password must be at least 6 characters.');
      return res.redirect('/profile');
    }
    const user = await User.findById(req.session.userId);
    const match = await user.matchPassword(currentPassword);
    if (!match) {
      req.flash('error', 'Current password is incorrect.');
      return res.redirect('/profile');
    }
    user.password = newPassword;
    await user.save();
    req.flash('success', 'Password changed successfully!');
    res.redirect('/profile');
  } catch (err) {
    req.flash('error', 'Password change failed.');
    res.redirect('/profile');
  }
};
