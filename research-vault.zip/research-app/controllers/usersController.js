const User = require('../models/User');
const Paper = require('../models/Paper');

exports.index = async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.render('users/index', { title: 'User Management', users });
  } catch (err) {
    req.flash('error', 'Failed to load users.');
    res.redirect('/dashboard');
  }
};

exports.edit = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) { req.flash('error', 'User not found.'); return res.redirect('/users'); }
    res.render('users/edit', { title: 'Edit User', editUser: user });
  } catch (err) {
    req.flash('error', 'User not found.');
    res.redirect('/users');
  }
};

exports.update = async (req, res) => {
  try {
    const { role } = req.body;
    if (!['admin', 'user'].includes(role)) {
      req.flash('error', 'Invalid role.');
      return res.redirect('/users');
    }
    await User.findByIdAndUpdate(req.params.id, { role });
    req.flash('success', 'User role updated.');
    res.redirect('/users');
  } catch (err) {
    req.flash('error', 'Update failed.');
    res.redirect('/users');
  }
};

exports.destroy = async (req, res) => {
  try {
    if (req.params.id === req.session.userId.toString()) {
      req.flash('error', 'Cannot delete your own account here.');
      return res.redirect('/users');
    }
    await User.findByIdAndDelete(req.params.id);
    req.flash('success', 'User deleted.');
    res.redirect('/users');
  } catch (err) {
    req.flash('error', 'Delete failed.');
    res.redirect('/users');
  }
};
