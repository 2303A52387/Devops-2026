const User = require('../models/User');
const Paper = require('../models/Paper');
const fs = require('fs');
const path = require('path');

exports.getDashboard = async (req, res) => {
  try {
    const totalPapers = await Paper.countDocuments();
    const totalUsers = await User.countDocuments();

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const recentUploads = await Paper.countDocuments({ createdAt: { $gte: thirtyDaysAgo } });

    // Calculate storage used
    const uploadDir = path.join(__dirname, '..', 'public', 'uploads', 'pdfs');
    let storageUsed = 0;
    try {
      const files = fs.readdirSync(uploadDir);
      files.forEach(file => {
        try {
          const stat = fs.statSync(path.join(uploadDir, file));
          storageUsed += stat.size;
        } catch (e) {}
      });
    } catch (e) {}
    const storageUsedMB = (storageUsed / (1024 * 1024)).toFixed(2);

    // Papers per month (last 6 months)
    const months = [];
    const papersPerMonth = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const start = new Date(d.getFullYear(), d.getMonth(), 1);
      const end = new Date(d.getFullYear(), d.getMonth() + 1, 0, 23, 59, 59);
      const count = await Paper.countDocuments({ createdAt: { $gte: start, $lte: end } });
      months.push(start.toLocaleString('default', { month: 'short', year: '2-digit' }));
      papersPerMonth.push(count);
    }

    // Papers by category
    const categoryAgg = await Paper.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    const recentPapers = await Paper.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('uploadedBy', 'name');

    res.render('dashboard/index', {
      title: 'Dashboard',
      totalPapers,
      totalUsers,
      recentUploads,
      storageUsedMB,
      months: JSON.stringify(months),
      papersPerMonth: JSON.stringify(papersPerMonth),
      categoryLabels: JSON.stringify(categoryAgg.map(c => c._id)),
      categoryCounts: JSON.stringify(categoryAgg.map(c => c.count)),
      recentPapers
    });
  } catch (err) {
    console.error(err);
    res.render('dashboard/index', {
      title: 'Dashboard',
      totalPapers: 0, totalUsers: 0, recentUploads: 0, storageUsedMB: 0,
      months: '[]', papersPerMonth: '[]',
      categoryLabels: '[]', categoryCounts: '[]',
      recentPapers: []
    });
  }
};
