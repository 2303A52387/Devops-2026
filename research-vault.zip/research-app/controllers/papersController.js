const Paper = require('../models/Paper');
const User = require('../models/User');
const fs = require('fs');
const path = require('path');

const CATEGORIES = ['Machine Learning', 'Deep Learning', 'Computer Vision', 'NLP', 'Bioinformatics', 'Data Science', 'Cybersecurity', 'IoT', 'Cloud Computing', 'Other'];

exports.index = async (req, res) => {
  try {
    const { search, category, year, sort } = req.query;
    let query = {};
    if (search) query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { author: { $regex: search, $options: 'i' } },
      { abstract: { $regex: search, $options: 'i' } }
    ];
    if (category) query.category = category;
    if (year) query.year = parseInt(year);

    let sortObj = { createdAt: -1 };
    if (sort === 'title') sortObj = { title: 1 };
    else if (sort === 'year') sortObj = { year: -1 };
    else if (sort === 'author') sortObj = { author: 1 };

    const papers = await Paper.find(query).sort(sortObj).populate('uploadedBy', 'name');
    const years = await Paper.distinct('year');

    res.render('papers/index', { title: 'Research Papers', papers, categories: CATEGORIES, years: years.sort((a, b) => b - a), search, selectedCategory: category, selectedYear: year, sort });
  } catch (err) {
    req.flash('error', 'Failed to load papers.');
    res.redirect('/dashboard');
  }
};

exports.create = (req, res) => {
  res.render('papers/create', { title: 'Upload Paper', categories: CATEGORIES });
};

exports.store = async (req, res) => {
  try {
    if (!req.file) {
      req.flash('error', 'Please upload a PDF file.');
      return res.redirect('/papers/create');
    }
    const { title, author, category, abstract, year } = req.body;
    if (!title || !author || !category || !abstract || !year) {
      fs.unlinkSync(req.file.path);
      req.flash('error', 'All fields are required.');
      return res.redirect('/papers/create');
    }
    const paper = await Paper.create({
      title, author, category, abstract,
      year: parseInt(year),
      pdfFile: req.file.filename,
      fileSize: req.file.size,
      uploadedBy: req.session.userId
    });
    await User.findByIdAndUpdate(req.session.userId, { $inc: { papersUploaded: 1 } });
    req.flash('success', 'Paper uploaded successfully!');
    res.redirect(`/papers/${paper._id}`);
  } catch (err) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (e) {}
    req.flash('error', 'Upload failed. Please try again.');
    res.redirect('/papers/create');
  }
};

exports.show = async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id).populate('uploadedBy', 'name email');
    if (!paper) { req.flash('error', 'Paper not found.'); return res.redirect('/papers'); }
    res.render('papers/show', { title: paper.title, paper });
  } catch (err) {
    req.flash('error', 'Paper not found.');
    res.redirect('/papers');
  }
};

exports.edit = async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) { req.flash('error', 'Paper not found.'); return res.redirect('/papers'); }
    const isOwner = paper.uploadedBy.toString() === req.session.userId.toString();
    if (!isOwner && req.session.role !== 'admin') {
      req.flash('error', 'Not authorized.');
      return res.redirect('/papers');
    }
    res.render('papers/edit', { title: 'Edit Paper', paper, categories: CATEGORIES });
  } catch (err) {
    req.flash('error', 'Paper not found.');
    res.redirect('/papers');
  }
};

exports.update = async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) { req.flash('error', 'Paper not found.'); return res.redirect('/papers'); }
    const isOwner = paper.uploadedBy.toString() === req.session.userId.toString();
    if (!isOwner && req.session.role !== 'admin') {
      req.flash('error', 'Not authorized.');
      return res.redirect('/papers');
    }
    const { title, author, category, abstract, year } = req.body;
    paper.title = title;
    paper.author = author;
    paper.category = category;
    paper.abstract = abstract;
    paper.year = parseInt(year);
    await paper.save();
    req.flash('success', 'Paper updated successfully!');
    res.redirect(`/papers/${paper._id}`);
  } catch (err) {
    req.flash('error', 'Update failed.');
    res.redirect('/papers');
  }
};

exports.destroy = async (req, res) => {
  try {
    const paper = await Paper.findById(req.params.id);
    if (!paper) { req.flash('error', 'Paper not found.'); return res.redirect('/papers'); }
    const isOwner = paper.uploadedBy.toString() === req.session.userId.toString();
    if (!isOwner && req.session.role !== 'admin') {
      req.flash('error', 'Not authorized.');
      return res.redirect('/papers');
    }
    const filePath = path.join(__dirname, '..', 'public', 'uploads', 'pdfs', paper.pdfFile);
    try { fs.unlinkSync(filePath); } catch (e) {}
    await Paper.findByIdAndDelete(req.params.id);
    req.flash('success', 'Paper deleted.');
    res.redirect('/papers');
  } catch (err) {
    req.flash('error', 'Delete failed.');
    res.redirect('/papers');
  }
};
