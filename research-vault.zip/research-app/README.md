# ResearchVault — Research Paper Management System

A full-stack web application for uploading, organizing, and managing research papers, built with **Express.js**, **MongoDB**, and **EJS**.

---

## 🚀 Quick Start (Local)

### 1. Prerequisites
- Node.js v18+ (https://nodejs.org)
- MongoDB Atlas account (https://cloud.mongodb.com) OR local MongoDB

### 2. Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/research-vault.git
cd research-vault
npm install
```

### 3. Environment Setup

Copy the example env file and fill in your values:

```bash
cp .env.example .env
```

Edit `.env`:
```
PORT=3000
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/research_db?retryWrites=true&w=majority
SESSION_SECRET=some_long_random_string_here_change_me
NODE_ENV=development
```

### 4. MongoDB Atlas Setup

1. Go to https://cloud.mongodb.com → Create a free cluster
2. Click **Connect** → **Connect your application**
3. Copy the connection string and paste into `MONGODB_URI` in `.env`
4. Replace `<username>` and `<password>` with your DB user credentials
5. Under **Network Access**, add `0.0.0.0/0` (allow all IPs) for development

### 5. Run the App

```bash
npm start
# or for development with auto-reload:
npm run dev
```

Visit: **http://localhost:3000**

---

## 📂 Project Structure

```
research-vault/
├── app.js                    # Entry point
├── package.json
├── .env                      # Your secrets (never commit)
├── .env.example              # Template
├── .gitignore
├── config/
│   └── db.js                 # MongoDB connection
├── controllers/
│   ├── authController.js     # Login, register, logout
│   ├── dashboardController.js
│   ├── papersController.js   # CRUD for papers
│   ├── profileController.js  # Profile & password
│   └── usersController.js    # Admin user management
├── middleware/
│   ├── auth.js               # isAuthenticated, isAdmin, isGuest
│   └── multer.js             # PDF & avatar upload config
├── models/
│   ├── User.js               # Mongoose User schema
│   └── Paper.js              # Mongoose Paper schema
├── routes/
│   ├── auth.js
│   ├── papers.js
│   ├── profile.js
│   └── users.js
├── views/
│   ├── partials/             # header, footer, sidebar, navbar
│   ├── auth/                 # login.ejs, register.ejs
│   ├── dashboard/            # index.ejs
│   ├── papers/               # index, create, edit, show
│   ├── users/                # index, edit
│   └── profile/              # index.ejs
└── public/
    ├── css/main.css
    ├── js/main.js
    └── uploads/
        ├── pdfs/             # Uploaded PDF files
        └── avatars/          # User profile pictures
```

---

## 🔐 Features

| Feature | Details |
|---------|---------|
| Auth | Session-based login/register with bcrypt password hashing |
| Dashboard | Stats cards + Chart.js bar & pie charts |
| Papers | Upload PDF, search, filter, sort, view, edit, delete |
| PDF Preview | Inline iframe preview on paper detail page |
| Users (Admin) | View all users, change roles, delete users |
| Profile | Edit name/email/avatar, change password |
| Roles | Admin and User roles with route protection |

---

## 📤 GitHub Upload Instructions

```bash
# 1. Initialize git in project folder
cd research-vault
git init

# 2. Add all files
git add .

# 3. Initial commit
git commit -m "Initial commit: ResearchVault app"

# 4. Create repo on GitHub, then add remote
git remote add origin https://github.com/YOUR_USERNAME/research-vault.git

# 5. Push
git branch -M main
git push -u origin main
```

> ⚠️ Make sure `.env` and `public/uploads/` are in `.gitignore` before pushing!

---

## 🧪 Default Routes

| Route | Method | Description |
|-------|--------|-------------|
| `/` | GET | Redirect to dashboard or login |
| `/auth/login` | GET/POST | Login page |
| `/auth/register` | GET/POST | Register page |
| `/auth/logout` | GET | Destroy session |
| `/dashboard` | GET | Dashboard with stats & charts |
| `/papers` | GET | List all papers |
| `/papers/create` | GET | Upload form |
| `/papers` | POST | Store new paper |
| `/papers/:id` | GET | Paper detail + PDF preview |
| `/papers/:id/edit` | GET | Edit form |
| `/papers/:id` | PUT | Update paper |
| `/papers/:id` | DELETE | Delete paper |
| `/users` | GET | Admin: list users |
| `/users/:id/edit` | GET | Admin: edit user role |
| `/users/:id` | PUT | Admin: update role |
| `/users/:id` | DELETE | Admin: delete user |
| `/profile` | GET | View profile |
| `/profile` | PUT | Update profile |
| `/profile/password` | PUT | Change password |

---

## 🛠 Tech Stack

- **Backend**: Node.js, Express.js
- **Database**: MongoDB with Mongoose ODM
- **Auth**: express-session + connect-mongo + bcryptjs
- **Views**: EJS templating
- **File Upload**: Multer
- **Charts**: Chart.js (CDN)
- **Icons**: Font Awesome 6
- **Fonts**: Syne + DM Sans (Google Fonts)

---

## 📝 License

MIT — free to use and modify.
